"""
Configuration du pipeline de prospection Site 4.0
"""

# === RECHERCHES GOOGLE MAPS ===
# Format : "secteur + ville"
# Le scraper boucle sur toutes les combinaisons secteur × ville

SECTEURS = [
    "restaurant",
    "hôtel",
    "plombier",
    "électricien",
    "serrurier",
    "menuisier",
    "avocat",
    "architecte",
    "cabinet comptable",
    "kinésithérapeute",
    "ostéopathe",
    "dentiste",
    "coiffeur",
    "boulangerie",
    "fleuriste",
    "garage automobile",
]

VILLES = [
    "Aix-en-Provence",
    "Marseille",
    # Ajouter tes villes cibles ici
]

# === SCORING (pondérations sur 100) ===
SCORING = {
    "site_absent_ou_obsolete": 30,   # ★★★ pas de site ou mauvais score
    "bons_avis": 25,                 # ★★★ note >= 4.0 et >= 20 avis
    "activite_haute_valeur": 20,     # ★★★ secteur premium
    "presence_reseaux": 10,          # ★★ présence Facebook/Insta
    "zone_geo_pertinente": 10,       # ★★ proximité
    "secteur_non_sature": 5,         # ★ peu de concurrence web
}

# Secteurs à haute valeur (panier moyen élevé)
SECTEURS_PREMIUM = [
    "hôtel", "restaurant", "avocat", "architecte",
    "cabinet comptable", "dentiste", "chirurgien",
]

# Seuils
SEUIL_NOTE_MIN = 4.0        # Note Google minimum
SEUIL_AVIS_MIN = 15         # Nombre d'avis minimum
SEUIL_PAGESPEED_MAUVAIS = 50  # En dessous = site obsolète
SEUIL_SCORE_SHORTLIST = 50  # Score minimum pour la shortlist

# === PAGESPEED API ===
# Gratuite, pas de clé nécessaire (mais rate-limited)
PAGESPEED_API_URL = "https://pagespeedonline.googleapis.com/pagespeedonline/v5/runPagespeed"

# === NOTION ===
NOTION_API_KEY = ""          # À remplir : secret_xxx
NOTION_DATABASE_ID = ""      # À remplir : ID de la DB prospects

# === DÉLAIS (politesse scraping) ===
DELAY_BETWEEN_SEARCHES = 3   # secondes entre chaque recherche Maps
DELAY_BETWEEN_PAGESPEED = 2  # secondes entre chaque appel PageSpeed
MAX_RESULTS_PER_SEARCH = 20  # nombre max de résultats par recherche Maps
