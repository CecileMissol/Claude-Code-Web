#!/usr/bin/env python3
"""
🎯 Pipeline de prospection Site 4.0
Lance les 4 modules en séquence :
  1. Scraping Google Maps
  2. Analyse des sites web
  3. Scoring multicritères
  4. Export Notion
"""

import asyncio
import argparse
import json
from pathlib import Path

from modules.m1_scraper_maps import run_extraction, save_raw_results
from modules.m2_analyzer import analyze_businesses
from modules.m3_scoring import score_all_businesses
from modules.m4_notion_export import export_to_notion


def main():
    parser = argparse.ArgumentParser(description="Pipeline de prospection Site 4.0")
    parser.add_argument("--secteur", type=str, help="Un seul secteur")
    parser.add_argument("--ville", type=str, help="Une seule ville")
    parser.add_argument("--skip-scrape", action="store_true", help="Reprendre depuis le JSON existant")
    parser.add_argument("--skip-notion", action="store_true", help="Ne pas exporter vers Notion")
    parser.add_argument("--all", action="store_true", help="Exporter tous les rangs (pas que A+B)")
    args = parser.parse_args()

    output_dir = Path(__file__).resolve().parent / "output"
    output_dir.mkdir(exist_ok=True)

    # ── ÉTAPE 1 : Scraping ──
    raw_path = output_dir / "raw_businesses.json"

    if args.skip_scrape and raw_path.exists():
        print("⏭️  Scraping ignoré — chargement du JSON existant")
        with open(raw_path, "r", encoding="utf-8") as f:
            raw_data = json.load(f)
    else:
        print("=" * 50)
        print("📍 ÉTAPE 1 — Scraping Google Maps")
        print("=" * 50)
        secteurs = [args.secteur] if args.secteur else None
        villes = [args.ville] if args.ville else None
        businesses = asyncio.run(run_extraction(secteurs, villes))
        save_raw_results(businesses)
        raw_data = [b.to_dict() if hasattr(b, 'to_dict') else b for b in businesses]

    # ── ÉTAPE 2 : Analyse ──
    print("\n" + "=" * 50)
    print("🔎 ÉTAPE 2 — Analyse des sites web")
    print("=" * 50)
    analyzed = analyze_businesses(raw_data)

    # ── ÉTAPE 3 : Scoring ──
    print("\n" + "=" * 50)
    print("📊 ÉTAPE 3 — Scoring multicritères")
    print("=" * 50)
    scored = score_all_businesses(analyzed)

    # ── ÉTAPE 4 : Export Notion ──
    if not args.skip_notion:
        print("\n" + "=" * 50)
        print("📤 ÉTAPE 4 — Export Notion")
        print("=" * 50)
        export_to_notion(scored, shortlist_only=not args.all)
    else:
        print("\n⏭️  Export Notion ignoré")

    print("\n" + "=" * 50)
    print("✅ Pipeline terminé !")
    print("=" * 50)


if __name__ == "__main__":
    main()
